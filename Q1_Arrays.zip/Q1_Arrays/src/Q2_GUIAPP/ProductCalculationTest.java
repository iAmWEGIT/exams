import static org.junit.Assert.*;
import org.junit.Test;

package Q2_GUIAPP;

/**
 *
 * @author RandomPc
 */
public class ProductCalculationTest {
    @test
    public void GetVat_withValidData_ReturnCorrectCalue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(525.0, calc.GetVat(), 0.001);
    }
    
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations cals = new ProductCalculations(3500);
        assertEquals(4200.0 calc.GetTotal(), 0.001);
    
    }
    
}
