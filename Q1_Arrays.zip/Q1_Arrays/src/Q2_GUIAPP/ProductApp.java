import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io*;

package Q2_GUIAPP;



/**
 *Question 2
 * @author ST10521004
 */
public class ProductApp extends JFrame implements ActionListener {
    JTextField txtCustomerName, txtPrice;
    JComboBox<String> cboProduct;
    JButton btnProcess;
    JMenueItem menueExit, menueProcess, menueClear;
    
  
    public ProductApp() {
        setTitle("Product App");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10)); 

        // Menu System
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        menuExit = new JMenuItem("Exit");
        menuExit.addActionListener(this);
        fileMenu.add(menuExit);
        
        JMenu toolsMenu = new JMenu("Tools");
        menuProcess = new JMenuItem("Process");
        menuProcess.addActionListener(this);
        menuClear = new JMenuItem("Clear");
        menuClear.addActionListener(this);
        toolsMenu.add(menuProcess);
        toolsMenu.add(menuClear);
        
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar); 

        // Form Objects
        add(new JLabel("Customer Name:"));
        txtCustomerName = new JTextField();
        add(txtCustomerName);

        add(new JLabel("Select Product:"));
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        cboProduct = new JComboBox<>(products);
        add(cboProduct);

        add(new JLabel("Enter Price:"));
        txtPrice = new JTextField();
        add(txtPrice);

        btnProcess = new JButton("PROCESS");
        btnProcess.addActionListener(this); 
        add(new JLabel("")); 
        add(btnProcess);

        setVisible(true); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == menuExit) {
            System.exit(0); 
        } else if (e.getSource() == menuClear) {
            txtCustomerName.setText("");
            txtPrice.setText("");
            cboProduct.setSelectedIndex(0); 
        } else if (e.getSource() == btnProcess || e.getSource() == menuProcess) {
            processSale();
        }
    }

    private void processSale() {
        try {
            String name = txtCustomerName.getText();
            String product = (String) cboProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText());

            ProductCalculations calc = new ProductCalculations(price);
            double vat = calc.GetVat();
            double commission = calc.GetCommission();
            double total = calc.GetTotal();

            String message = "Customer Name: " + name + "\n" +
                             "Product: " + product + "\n" +
                             "VAT: R " + vat + "\n" +
                             "COMMISSION: R " + commission + "\n" +
                             "TOTAL: R " + total;
            JOptionPane.showMessageDialog(this, message);

            saveToFile(name, product, vat, commission, total);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for price!");
        }
    }

    private void saveToFile(String name, String product, double vat, double comm, double total) {
        try {
            FileWriter fw = new FileWriter("data.txt", true);
            PrintWriter pw = new PrintWriter(fw);

            pw.println("DATA LOG");
            pw.println("**************************");
            pw.println("Customer Name: " + name);
            pw.println("Product: " + product);
            pw.println("VAT: R " + vat);
            pw.println("COMMISSION: R " + comm);
            pw.println("TOTAL: R " + total);
            pw.println("**************************");
            pw.close(); 
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving to file.");
        }
    }

    public static void main(String[] args) {
        new ProductApp();
    }
}

    
