/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q1_arrays;

/**
 *
 * @author RandomPc
 */
public class ProductCalculations implements IProductCalculations{
   
    private double price;
    public ProductCalculations (double price) {
        this.price = price; 
        
        @Override 
        public double GetVat() {
        return price * 0.15;
    }
        
        @Override 
        public double Get() Commission{
        return price * 0.05;
    }
        
        @Override 
        public double GetTotal() {
        return price * GetVat() + GetCommission();
        
    }
        
        
    }
    }
 
