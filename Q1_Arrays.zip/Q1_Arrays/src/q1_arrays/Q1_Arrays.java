/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package q1_arrays;

/**
 *
 * @author ST10521004
 */
public class Q1_Arrays {

    /**
     * @param args the command line arguments
     * 
     */
    //Single dimentional array of prosuct names... 
    public static void main(String[] args) {
        String[]products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        
        //2dimentional Array of sales Rows = Products , columns =months
        
        int [][] sales ={
            {25, 18, 20}, 
            {15, 10, 12},
            {18, 15, 20}};
                
        int highestSales =0; 
        String popularProduct = "" ;
               
        System.out.println ("PRODUCT SALES REPORT - 2026");
        System.out.println ( "*******************************");
         
    for (int i = 0; i < products.length; i++) {
        int total =0;  //Loops for totals and average...
        
        for (int j = 0; j< sales[i].length; j++) {
            total += sales[i][j];
        }//Add up Sales 
        
        //Lets calculate avarage..
        double average = (double) total / sales[i].length;
        
        //lets print the total AVERAGe
        System.out.println("TOTAL PRODUCT SALES:" +total);
        System.out.println ( "AVERAGE PRODUCT SALES: "+ average);
        System.out.println ( "MOST POPULAR PRODUCT"+ products[i]);
        
        //which is the most popular product
        if (total >highestSales){
            highestSales = total;
            popularProduct = products[i];
        }
       System.out.println ( "MOST POPULAR PRODUCT" + popularProduct + "(" + highestSales + ")" );
       
    }
        }
        
        
        // TODO code application logic here
    }
    

